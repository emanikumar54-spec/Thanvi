/**
 * MusicPlayer — Persistent background music using HTML5 Audio.
 *
 * HOW TO REPLACE THE SONG
 * ───────────────────────
 * 1. Drop your new MP3 into:  artifacts/birthday-surprise/public/music/song.mp3
 * 2. That's it — no code changes needed.
 *
 * Mounted once in App.tsx; survives every stage transition so the song
 * never restarts when the user moves between sections.
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { VolumeX } from 'lucide-react';

// ─── Config ───────────────────────────────────────────────────────────────────
const SONG_PATH   = 'music/song.mp3'; // relative to public/
const TARGET_VOL  = 0.35;             // 35 %
const FADE_IN_MS  = 1800;             // fade-in duration on play
const FADE_OUT_MS = 900;              // fade-out duration on pause
// ─────────────────────────────────────────────────────────────────────────────

/** Smoothly ramp audio.volume from its current value to `target` over `ms` ms. */
function fadeVolume(
  audio: HTMLAudioElement,
  target: number,
  ms: number,
  onComplete?: () => void,
): () => void {
  const start     = audio.volume;
  const startTime = performance.now();
  let rafId: number;

  const tick = (now: number) => {
    const t = Math.max(0, Math.min(1, (now - startTime) / ms));
    // ease-in-out cubic
    const eased = t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
    audio.volume = Math.max(0, Math.min(1, start + (target - start) * eased));
    if (t < 1) {
      rafId = requestAnimationFrame(tick);
    } else {
      audio.volume = target;
      onComplete?.();
    }
  };

  rafId = requestAnimationFrame(tick);
  return () => cancelAnimationFrame(rafId); // cancel handle
}

// ─────────────────────────────────────────────────────────────────────────────

export default function MusicPlayer() {
  const audioRef      = useRef<HTMLAudioElement | null>(null);
  const cancelFadeRef = useRef<(() => void) | null>(null);
  const startedRef    = useRef(false); // ensure we only trigger start logic once

  const [playing, setPlaying] = useState(false);

  // Build URL using Vite's base path so it resolves correctly in dev & prod
  const src = `${import.meta.env.BASE_URL}${SONG_PATH}`;

  // ── Start the song with a fade-in ─────────────────────────────────────────
  const startMusic = useCallback(() => {
    const audio = audioRef.current;
    if (!audio || startedRef.current) return;
    startedRef.current = true;

    audio.volume = 0;
    audio.play()
      .then(() => {
        cancelFadeRef.current?.();
        cancelFadeRef.current = fadeVolume(audio, TARGET_VOL, FADE_IN_MS);
      })
      .catch(() => {
        // Play was rejected (policy still active) — reset so the next gesture retries
        startedRef.current = false;
      });
  }, []);

  // ── Create audio element once; attempt autoplay immediately ───────────────
  useEffect(() => {
    const audio       = new Audio(src);
    audio.loop        = true;
    audio.volume      = 0;
    audio.preload     = 'auto';
    audioRef.current  = audio;

    const onPlay  = () => setPlaying(true);
    const onPause = () => setPlaying(false);
    audio.addEventListener('play',  onPlay);
    audio.addEventListener('pause', onPause);

    // Try autoplay immediately — succeeds on desktop or if the browser is
    // permissive; mobile browsers will reject it and we fall back below.
    audio.play()
      .then(() => {
        startedRef.current = true;
        cancelFadeRef.current = fadeVolume(audio, TARGET_VOL, FADE_IN_MS);
      })
      .catch(() => {
        // Autoplay blocked — will be triggered by first user interaction
      });

    return () => {
      cancelFadeRef.current?.();
      audio.pause();
      audio.removeEventListener('play',  onPlay);
      audio.removeEventListener('pause', onPause);
      audioRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ── Fallback: start on first interaction if autoplay was blocked ──────────
  useEffect(() => {
    const handle = () => {
      if (!startedRef.current) startMusic();
    };

    window.addEventListener('touchstart', handle, { passive: true });
    window.addEventListener('click',      handle);
    window.addEventListener('keydown',    handle);

    return () => {
      window.removeEventListener('touchstart', handle);
      window.removeEventListener('click',      handle);
      window.removeEventListener('keydown',    handle);
    };
  }, [startMusic]);

  // ── Manual toggle with fade ───────────────────────────────────────────────
  const toggle = useCallback(() => {
    const audio = audioRef.current;
    if (!audio) return;

    // Cancel any in-progress fade
    cancelFadeRef.current?.();

    if (audio.paused) {
      audio.volume = 0;
      audio.play().then(() => {
        cancelFadeRef.current = fadeVolume(audio, TARGET_VOL, FADE_IN_MS);
      }).catch(() => {});
    } else {
      cancelFadeRef.current = fadeVolume(audio, 0, FADE_OUT_MS, () => {
        audio.pause();
        audio.volume = 0;
      });
    }
  }, []);

  // ─── UI ───────────────────────────────────────────────────────────────────
  return (
    <motion.button
      onClick={toggle}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 1.5, duration: 0.5, ease: 'easeOut' }}
      whileTap={{ scale: 0.87 }}
      aria-label={playing ? 'Pause music' : 'Play music'}
      className="fixed bottom-5 right-5 z-50 flex items-center gap-1.5 px-3 py-2 rounded-full backdrop-blur-md border border-white/15 text-white/65 hover:text-white transition-colors shadow-[0_4px_20px_rgba(0,0,0,0.45)]"
      style={{ background: 'rgba(0,0,0,0.46)' }}
    >
      <AnimatePresence mode="wait" initial={false}>
        {playing ? (
          <motion.span
            key="on"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.18 }}
            className="flex items-center gap-1.5"
          >
            {/* Animated equaliser bars */}
            <span className="flex items-end gap-[2.5px]" style={{ height: 13 }}>
              {[0.45, 0.85, 0.55, 1, 0.48].map((h, i) => (
                <motion.span
                  key={i}
                  className="w-[2px] rounded-full bg-primary block"
                  animate={{ scaleY: [h, 1, h * 0.5, 0.88, h] }}
                  transition={{
                    duration: 0.88,
                    repeat: Infinity,
                    delay: i * 0.12,
                    ease: 'easeInOut',
                  }}
                  style={{ height: '100%', transformOrigin: 'bottom' }}
                />
              ))}
            </span>
            <span style={{ fontSize: 10, letterSpacing: '0.08em' }}>Music</span>
          </motion.span>
        ) : (
          <motion.span
            key="off"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.18 }}
            className="flex items-center gap-1.5"
          >
            <VolumeX className="w-3.5 h-3.5" />
            <span style={{ fontSize: 10, letterSpacing: '0.08em' }}>Music</span>
          </motion.span>
        )}
      </AnimatePresence>
    </motion.button>
  );
}
