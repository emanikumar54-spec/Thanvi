import React, { useEffect, useRef } from 'react';

// ─── Enhanced fireworks canvas ────────────────────────────────────────────────
// Romantic color palette: rose gold, pink, white, crimson, champagne
// Particle types: round sparks + glowing trail + heart-shaped bursts
// Uses shadowBlur for glow effect

const COLORS = [
  '#f43f5e', '#fda4af', '#ffffff', '#e11d48',
  '#fbbf24', '#fbcfe8', '#fca5a5', '#fef3c7',
];

interface Particle {
  x: number; y: number;
  vx: number; vy: number;
  color: string;
  alpha: number;
  life: number; maxLife: number;
  size: number;
  glow: boolean;
  type: 'spark' | 'heart';
}

function drawHeart(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, color: string, alpha: number) {
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.fillStyle   = color;
  ctx.shadowColor = color;
  ctx.shadowBlur  = 6;
  ctx.beginPath();
  const s = size * 0.5;
  ctx.moveTo(x, y + s * 0.4);
  ctx.bezierCurveTo(x, y - s * 0.6, x - s * 1.4, y - s * 0.6, x - s * 1.4, y + s * 0.2);
  ctx.bezierCurveTo(x - s * 1.4, y + s * 1, x, y + s * 1.6, x, y + s * 1.6);
  ctx.bezierCurveTo(x, y + s * 1.6, x + s * 1.4, y + s * 1, x + s * 1.4, y + s * 0.2);
  ctx.bezierCurveTo(x + s * 1.4, y - s * 0.6, x, y - s * 0.6, x, y + s * 0.4);
  ctx.fill();
  ctx.restore();
}

export default function Fireworks() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const setSize = () => {
      canvas.width  = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    setSize();
    window.addEventListener('resize', setSize);

    const particles: Particle[] = [];

    const createExplosion = (x: number, y: number) => {
      const count = 110 + Math.floor(Math.random() * 70);
      for (let i = 0; i < count; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = Math.random() * 5.5 + 1.5;
        const isHeart = Math.random() < 0.18;
        particles.push({
          x, y,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          color: COLORS[Math.floor(Math.random() * COLORS.length)],
          alpha: 1,
          life: 0,
          maxLife: 55 + Math.random() * 50,
          size: isHeart ? Math.random() * 2.5 + 1.5 : Math.random() * 3.5 + 1,
          glow: Math.random() < 0.5,
          type: isHeart ? 'heart' : 'spark',
        });
      }
    };

    // Launch at 3 randomized positions simultaneously on first burst
    const firstBurst = () => {
      for (let i = 0; i < 3; i++) {
        setTimeout(() => {
          createExplosion(
            canvas.width  * (0.2 + Math.random() * 0.6),
            canvas.height * (0.1 + Math.random() * 0.4),
          );
        }, i * 300);
      }
    };
    firstBurst();

    let lastLaunch = 0;
    let animId: number;

    const animate = (time: number) => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Regular auto-launch every 1.1s
      if (time - lastLaunch > 1100) {
        createExplosion(
          canvas.width  * (0.1 + Math.random() * 0.8),
          canvas.height * (0.08 + Math.random() * 0.45),
        );
        // Occasionally fire two at once
        if (Math.random() < 0.35) {
          createExplosion(
            canvas.width  * (0.1 + Math.random() * 0.8),
            canvas.height * (0.08 + Math.random() * 0.45),
          );
        }
        lastLaunch = time;
      }

      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.x  += p.vx;
        p.y  += p.vy;
        p.vy += 0.045; // gravity
        p.vx += Math.sin(p.life * 0.08) * 0.12; // waver
        p.life++;
        p.alpha = Math.pow(1 - p.life / p.maxLife, 1.4);

        if (p.alpha <= 0) { particles.splice(i, 1); continue; }

        if (p.type === 'heart') {
          drawHeart(ctx, p.x, p.y, p.size, p.color, p.alpha);
        } else {
          ctx.save();
          ctx.globalAlpha = p.alpha;
          ctx.fillStyle   = p.color;
          if (p.glow) {
            ctx.shadowColor = p.color;
            ctx.shadowBlur  = 8;
          }
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fill();
          // Trail
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p.x - p.vx * 2, p.y - p.vy * 2);
          ctx.strokeStyle = p.color;
          ctx.lineWidth   = p.size * 0.7;
          ctx.globalAlpha = p.alpha * 0.4;
          ctx.stroke();
          ctx.restore();
        }
      }

      animId = requestAnimationFrame(animate);
    };

    animId = requestAnimationFrame(animate);

    return () => {
      window.removeEventListener('resize', setSize);
      cancelAnimationFrame(animId);
    };
  }, []);

  return <canvas ref={canvasRef} className="fixed inset-0 pointer-events-none" style={{ zIndex: 3 }} />;
}
