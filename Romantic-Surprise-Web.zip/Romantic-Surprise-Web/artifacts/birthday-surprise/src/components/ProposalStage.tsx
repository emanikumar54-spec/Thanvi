import { useEffect, useId, useState, type JSX } from 'react';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { RefreshCcw } from 'lucide-react';
import WeddingEnding from './WeddingEnding';
import photo1 from '@assets/IMG_20260613_200810_588_1784907587652.jpg';
import photo2 from '@assets/Snapchat-1181800331_1784907587687.jpg';
import photo3 from '@assets/IMG_20260722_121359_774_1784907587713.jpg';
import photo4 from '@assets/Snapchat-774222832_1784907587747.jpg';
import photo5 from '@assets/IMG_20260722_12162947_1784907587773.jpg';
import photo6 from '@assets/IMG_20260722_121354_524_1784907587812.jpg';

const HEART_PATH =
  'M210 352 C178 326 48 244 48 145 C48 78 94 40 148 40 C178 40 199 56 210 76 C221 56 242 40 272 40 C326 40 372 78 372 145 C372 244 242 326 210 352 Z';

const HEART_ECHO_LINES = [
  { scale: 0.974, color: 'rgba(255, 221, 235, .48)', width: 0.55, delay: 0.04 },
  { scale: 0.981, color: 'rgba(255, 173, 207, .55)', width: 0.62, delay: 0.09 },
  { scale: 0.988, color: 'rgba(255, 240, 247, .58)', width: 0.48, delay: 0.14 },
  { scale: 0.995, color: 'rgba(246, 143, 187, .66)', width: 0.72, delay: 0.19 },
  { scale: 1.005, color: 'rgba(255, 231, 241, .55)', width: 0.52, delay: 0.24 },
  { scale: 1.012, color: 'rgba(244, 137, 181, .48)', width: 0.64, delay: 0.29 },
  { scale: 1.019, color: 'rgba(255, 247, 250, .40)', width: 0.46, delay: 0.34 },
];

const MEMORIES = [
  { src: photo1, x: 77, y: 26, label: 'A favorite memory, first' },
  { src: photo2, x: 165, y: 26, label: 'A favorite memory, second' },
  { src: photo3, x: 253, y: 26, label: 'A favorite memory, third' },
  { src: photo4, x: 77, y: 182, label: 'A favorite memory, fourth' },
  { src: photo5, x: 165, y: 182, label: 'A favorite memory, fifth' },
  { src: photo6, x: 253, y: 182, label: 'A favorite memory, sixth' },
];

const AMBIENT_HEARTS = Array.from({ length: 7 }, (_, index) => ({
  left: `${9 + index * 13}%`,
  delay: index * 0.8,
  duration: 7 + (index % 3) * 1.1,
  size: 10 + (index % 3) * 4,
}));

export default function ProposalStage({ onReplay }: { onReplay: () => void }): JSX.Element {
  const [chapter, setChapter] = useState<'memory' | 'name' | 'question' | 'answer'>('memory');
  const reducedMotion = useReducedMotion();
  const uniqueId = useId().replace(/:/g, '');
  const clipId = `proposal-heart-${uniqueId}`;
  const glowId = `proposal-glow-${uniqueId}`;

  useEffect(() => {
    const nameDelay = reducedMotion ? 450 : 7800;
    const questionDelay = reducedMotion ? 1100 : 8800;
    const nameTimer = window.setTimeout(() => setChapter('name'), nameDelay);
    const questionTimer = window.setTimeout(() => setChapter('question'), questionDelay);
    return () => {
      window.clearTimeout(nameTimer);
      window.clearTimeout(questionTimer);
    };
  }, [reducedMotion]);

  const answerProposal = () => {
    setChapter('answer');
  };

  if (chapter === 'answer') {
    return <WeddingEnding />;
  }

  return (
    <section
      className="proposal-stage"
      data-testid="section-proposal-stage"
      aria-label="A personal story and marriage proposal"
    >
      <style>{`
        .proposal-stage {
          --proposal-rose: #f4a5c4;
          --proposal-blush: #ffe7f0;
          position: fixed;
          inset: 0;
          isolation: isolate;
          display: flex;
          z-index: 40;
          width: 100vw;
          min-height: 100dvh;
          align-items: center;
          justify-content: center;
          overflow-x: hidden;
          overflow-y: auto;
          overscroll-behavior: contain;
          padding: clamp(18px, 4vh, 38px) 18px;
          color: #fff2f7;
          background:
            radial-gradient(ellipse at 50% 42%, rgba(95, 21, 53, .22), transparent 52%),
            radial-gradient(ellipse at 50% 100%, rgba(50, 8, 28, .20), transparent 46%),
            #080507;
          text-align: center;
        }
        .proposal-stage::before {
          position: absolute;
          z-index: -1;
          inset: 0;
          content: "";
          pointer-events: none;
          opacity: .15;
          background-image: radial-gradient(rgba(255,255,255,.42) .55px, transparent .7px);
          background-size: 21px 21px;
          mask-image: linear-gradient(transparent, #000 20%, #000 80%, transparent);
        }
        .proposal-stage * { box-sizing: border-box; }
        .proposal-inner {
          position: relative;
          display: flex;
          width: min(100%, 760px);
          min-height: min(100%, 740px);
          flex-direction: column;
          align-items: center;
          justify-content: center;
          padding: 10px 0;
        }
        .proposal-art {
          position: relative;
          z-index: 1;
          display: block;
          width: min(88vw, 530px);
          max-height: 57dvh;
          overflow: visible;
          flex: 0 1 auto;
          filter: drop-shadow(0 0 22px rgba(233, 96, 151, .12));
        }
        .proposal-copy {
          z-index: 2;
          min-height: 120px;
          width: 100%;
          margin-top: clamp(-16px, -2vh, -4px);
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: flex-start;
        }
        .proposal-name {
          margin: 0;
          color: #ffe5ee;
          font-family: 'Great Vibes', cursive;
          font-size: clamp(44px, 9vw, 72px);
          font-weight: 400;
          line-height: 1.04;
          text-shadow: 0 0 28px rgba(245, 153, 188, .34);
        }
        .proposal-question {
          margin: 8px 0 0;
          color: #fff5f8;
          font-family: 'Playfair Display', Georgia, serif;
          font-size: clamp(22px, 5.2vw, 34px);
          font-weight: 400;
          line-height: 1.25;
          text-shadow: 0 3px 20px rgba(245, 120, 169, .22);
        }
        .proposal-actions {
          display: flex;
          align-items: center;
          justify-content: center;
          flex-wrap: wrap;
          gap: 12px;
          margin-top: 23px;
        }
        .proposal-replay-button {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          margin-top: 16px;
          padding: 10px 16px;
          border: 1px solid rgba(255, 235, 242, .2);
          border-radius: 999px;
          color: rgba(255, 237, 245, .68);
          background: rgba(255, 255, 255, .035);
          cursor: pointer;
          font: 500 12px/1 'Playfair Display', Georgia, serif;
          letter-spacing: .04em;
          transition: color .2s ease, border-color .2s ease, background .2s ease;
          touch-action: manipulation;
        }
        .proposal-replay-button:hover {
          color: #fff5f8;
          border-color: rgba(255, 235, 242, .42);
          background: rgba(255, 255, 255, .08);
        }
        .proposal-replay-button:focus-visible { outline: 2px solid #ffd7e7; outline-offset: 4px; }
        .proposal-button {
          min-width: 144px;
          min-height: 52px;
          padding: 13px 23px;
          border: 1px solid rgba(255, 222, 236, .46);
          border-radius: 999px;
          color: #fff6f9;
          background: linear-gradient(135deg, rgba(175, 54, 102, .82), rgba(107, 27, 65, .88));
          box-shadow: 0 8px 30px rgba(120, 31, 69, .28), inset 0 1px rgba(255,255,255,.12);
          cursor: pointer;
          font: 600 13px/1 'Playfair Display', Georgia, serif;
          letter-spacing: .13em;
          transition: transform .2s ease, background .2s ease, border-color .2s ease;
          touch-action: manipulation;
        }
        .proposal-button:hover { transform: translateY(-2px); background: linear-gradient(135deg, rgba(206, 80, 128, .94), rgba(128, 36, 77, .96)); border-color: rgba(255, 232, 242, .8); }
        .proposal-button:active { transform: scale(.97); }
        .proposal-button:focus-visible { outline: 2px solid #ffd7e7; outline-offset: 4px; }
        .proposal-ambient {
          position: absolute;
          z-index: 0;
          inset: 0;
          overflow: hidden;
          pointer-events: none;
        }
        .proposal-float {
          position: absolute;
          bottom: -38px;
          color: rgba(248, 149, 187, .54);
          filter: drop-shadow(0 0 9px rgba(255, 126, 174, .24));
          animation: proposal-rise var(--float-duration) ease-in var(--float-delay) infinite;
        }
        .proposal-spark {
          position: absolute;
          width: 3px;
          height: 3px;
          border-radius: 50%;
          background: #fff1f6;
          box-shadow: 0 0 7px 2px rgba(249, 163, 195, .55);
          animation: proposal-twinkle 3.2s ease-in-out var(--spark-delay) infinite;
        }
        @keyframes proposal-rise {
          0% { opacity: 0; transform: translate3d(0, 0, 0) rotate(-8deg) scale(.8); }
          15% { opacity: .7; }
          100% { opacity: 0; transform: translate3d(14px, -105vh, 0) rotate(20deg) scale(1.2); }
        }
        @keyframes proposal-twinkle {
          0%, 100% { opacity: .14; transform: scale(.65); }
          50% { opacity: .8; transform: scale(1.25); }
        }
        @media (max-height: 650px) {
          .proposal-stage { padding-top: 12px; padding-bottom: 12px; }
          .proposal-art { width: min(74vw, 410px); max-height: 50dvh; }
          .proposal-copy { min-height: 104px; margin-top: -10px; }
          .proposal-actions { margin-top: 14px; }
        }
        @media (max-width: 480px) {
          .proposal-inner { min-height: 0; }
          .proposal-art { width: min(94vw, 460px); max-height: 54dvh; }
          .proposal-copy { min-height: 128px; }
          .proposal-actions { gap: 9px; margin-top: 18px; }
          .proposal-button { min-width: 138px; min-height: 54px; }
        }
        @media (prefers-reduced-motion: reduce) {
          .proposal-stage *, .proposal-stage *::before, .proposal-stage *::after {
            scroll-behavior: auto !important;
          }
          .proposal-float, .proposal-spark { animation: none !important; }
          .proposal-button, .proposal-replay-button { transition: none; }
        }
      `}</style>

      <div className="proposal-ambient" aria-hidden="true">
        {AMBIENT_HEARTS.map((heart, index) => (
          <span
            className="proposal-float"
            key={`ambient-${index}`}
            style={{
              left: heart.left,
              fontSize: `${heart.size}px`,
              ['--float-duration' as string]: `${heart.duration}s`,
              ['--float-delay' as string]: `${heart.delay}s`,
            }}
          >
            ♥
          </span>
        ))}
        {[0, 1, 2, 3, 4, 5, 6, 7].map((sparkle, index) => (
          <i
            key={`spark-${sparkle}`}
            className="proposal-spark"
            style={{
              left: `${12 + ((index * 31) % 77)}%`,
              top: `${13 + ((index * 23) % 69)}%`,
              ['--spark-delay' as string]: `${index * 0.43}s`,
            }}
          />
        ))}
      </div>

      <div className="proposal-inner">
        <svg
          className="proposal-art"
          viewBox="0 0 420 390"
          role="img"
          aria-label="A glowing heart slowly filling with six memories"
          data-testid="art-memory-heart"
        >
          <defs>
            <clipPath id={clipId}>
              <path d={HEART_PATH} />
            </clipPath>
            <filter id={glowId} x="-30%" y="-30%" width="160%" height="160%">
              <feGaussianBlur stdDeviation="5" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          <g clipPath={`url(#${clipId})`}>
            <rect x="0" y="0" width="420" height="390" fill="#160911" />
            {MEMORIES.map((memory, index) => (
              <motion.g
                key={memory.src}
                initial={{ opacity: 0, scale: reducedMotion ? 1 : 1.12, filter: reducedMotion ? 'blur(0px)' : 'blur(8px)' }}
                animate={{ opacity: 1, scale: 1, filter: 'blur(0px)' }}
                transition={{
                  opacity: { duration: reducedMotion ? 0.01 : 1.05, delay: reducedMotion ? 0 : 1.1 + index * 0.78 },
                  scale: { duration: reducedMotion ? 0.01 : 1.8, delay: reducedMotion ? 0 : 1.1 + index * 0.78, ease: [0.2, 0.7, 0.25, 1] },
                  filter: { duration: reducedMotion ? 0.01 : 1.55, delay: reducedMotion ? 0 : 1.1 + index * 0.78, ease: 'easeOut' },
                }}
                style={{ transformOrigin: `${memory.x + 44}px ${memory.y + 78}px` }}
                data-testid={`memory-tile-${index + 1}`}
              >
                <image
                  href={memory.src}
                  x={memory.x}
                  y={memory.y}
                  width="89"
                  height="158"
                  preserveAspectRatio="xMidYMid meet"
                  aria-label={memory.label}
                />
              </motion.g>
            ))}
            <rect x="0" y="0" width="420" height="390" fill="rgba(114, 32, 70, .12)" />
          </g>

          <path
            d={HEART_PATH}
            fill="none"
            stroke="rgba(255, 190, 216, .38)"
            strokeWidth="5"
            pathLength="1000"
            strokeDasharray="1000"
            strokeDashoffset={reducedMotion ? 0 : 1000}
            filter={`url(#${glowId})`}
            data-testid="heart-soft-glow"
          >
            {!reducedMotion && (
              <animate
                attributeName="stroke-dashoffset"
                from="1000"
                to="0"
                dur="6.35s"
                fill="freeze"
              />
            )}
          </path>
          <motion.path
            d={HEART_PATH}
            fill="none"
            stroke="url(#heart-stroke)"
            strokeWidth="1.65"
            strokeLinecap="round"
            pathLength="1000"
            initial={{ strokeDashoffset: reducedMotion ? 0 : 1000 }}
            animate={{ strokeDashoffset: 0 }}
            transition={{ duration: reducedMotion ? 0.01 : 6.35, ease: 'easeInOut' }}
            style={{ strokeDasharray: 1000 }}
            data-testid="heart-contour"
          />
          {HEART_ECHO_LINES.map((line, index) => {
            const centerX = 210;
            const centerY = 196;
            const offsetX = centerX * (1 - line.scale);
            const offsetY = centerY * (1 - line.scale);
            return (
              <motion.path
                key={`heart-echo-${index}`}
                d={HEART_PATH}
                fill="none"
                stroke={line.color}
                strokeWidth={line.width}
                strokeLinecap="round"
                pathLength="1000"
                initial={{ strokeDashoffset: reducedMotion ? 0 : 1000 }}
                animate={{ strokeDashoffset: 0 }}
                transition={{
                  duration: reducedMotion ? 0.01 : 6.35,
                  delay: reducedMotion ? 0 : line.delay,
                  ease: 'easeInOut',
                }}
                transform={`translate(${offsetX} ${offsetY}) scale(${line.scale})`}
                style={{ strokeDasharray: 1000 }}
                data-testid={`heart-echo-line-${index + 1}`}
              />
            );
          })}
          <path
            d={HEART_PATH}
            fill="none"
            stroke="rgba(255, 243, 249, .48)"
            strokeWidth=".65"
            pathLength="1000"
            strokeDasharray="1000"
            strokeDashoffset={reducedMotion ? 0 : 1000}
            transform="translate(0 0) scale(.986 .986)"
            style={{ transformOrigin: '210px 196px' }}
            data-testid="heart-inner-line"
          >
            {!reducedMotion && (
              <animate
                attributeName="stroke-dashoffset"
                from="1000"
                to="0"
                dur="6.8s"
                fill="freeze"
              />
            )}
          </path>
          {!reducedMotion && (
            <>
              <circle r="2.1" fill="#fff7fa" filter={`url(#${glowId})`} data-testid="heart-tracing-spark">
                <animateMotion dur="6.35s" fill="freeze" path={HEART_PATH} />
              </circle>
              <circle r="1.35" fill="#f4a0c1" filter={`url(#${glowId})`}>
                <animateMotion dur="6.35s" begin="1.6s" fill="freeze" path={HEART_PATH} />
              </circle>
            </>
          )}
          <defs>
            <linearGradient id="heart-stroke" x1="40" y1="40" x2="370" y2="360" gradientUnits="userSpaceOnUse">
              <stop stopColor="#fff4f8" />
              <stop offset=".45" stopColor="#f4a0c1" />
              <stop offset="1" stopColor="#fff2f8" />
            </linearGradient>
          </defs>
        </svg>

        <div className="proposal-copy" aria-live="polite">
          <AnimatePresence mode="wait">
            {(chapter === 'name' || chapter === 'question') && (
              <motion.h1
                key="thanvi"
                className="proposal-name"
                initial={{ opacity: 0, y: 12, filter: 'blur(8px)' }}
                animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
                transition={{ duration: reducedMotion ? 0.01 : 1.15, ease: [0.2, 0.7, 0.2, 1] }}
                data-testid="text-thanvi-reveal"
              >
                Thanvi ❤️
              </motion.h1>
            )}
          </AnimatePresence>

          <AnimatePresence>
            {chapter === 'question' && (
              <motion.div
                key="question-block"
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: reducedMotion ? 0.01 : 1, ease: 'easeOut' }}
                data-testid="proposal-question-block"
              >
                <p className="proposal-question" data-testid="text-proposal-question">Will you marry me? 💍</p>
                <div className="proposal-actions">
                  <motion.button
                    type="button"
                    className="proposal-button"
                    onClick={answerProposal}
                    whileHover={reducedMotion ? undefined : { y: -2 }}
                    whileTap={reducedMotion ? undefined : { scale: 0.97 }}
                    aria-label="Answer yes"
                    data-testid="button-yes"
                  >
                    YES ❤️
                  </motion.button>
                </div>
                <button
                  type="button"
                  className="proposal-replay-button"
                  onClick={onReplay}
                  aria-label="Replay from beginning"
                  data-testid="button-replay-proposal"
                >
                  <RefreshCcw size={14} aria-hidden="true" />
                  <span>Replay from beginning</span>
                </button>
              </motion.div>
            )}
          </AnimatePresence>

        </div>
      </div>
    </section>
  );
}