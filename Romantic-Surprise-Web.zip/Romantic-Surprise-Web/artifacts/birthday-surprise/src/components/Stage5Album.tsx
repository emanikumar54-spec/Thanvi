import React, { useState, useRef, useCallback, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, Pause, Play, ArrowRight, Heart } from 'lucide-react';

// ─────────────────────────────────────────────────────────────────────────────
// ADD YOUR PHOTOS HERE
// Replace the import paths below with your own images (keep the @assets/ prefix).
// To add more photos: copy a photo object, set `src` to your import, update `caption`.
// ─────────────────────────────────────────────────────────────────────────────
import photo1  from '@assets/IMG_20260613_200810_588_1784907587652.jpg';
import photo2  from '@assets/Snapchat-1181800331_1784907587687.jpg';
import photo3  from '@assets/IMG_20260722_121359_774_1784907587713.jpg';
import photo4  from '@assets/Snapchat-774222832_1784907587747.jpg';
import photo5  from '@assets/IMG_20260722_12162947_1784907587773.jpg';
import photo6  from '@assets/IMG_20260722_121354_524_1784907587812.jpg';
import photo7  from '@assets/Snapchat-1514355067_1784907587868.jpg';
import photo8  from '@assets/IMG_20260722_12165797_1784909181908.jpg';
import photo9  from '@assets/Snapchat-543636971_1784909181930.jpg';
import photo10 from '@assets/Snapchat-119128278_1784909181953.jpg';
import photo11 from '@assets/Snapchat-658989745_1784909181970.jpg';
import photo12 from '@assets/IMG_20260722_12162947_1784909181995.jpg';

const PHOTOS = [
  { id: 1,  src: photo1,  caption: 'That smile that lights up every room.' },
  { id: 2,  src: photo2,  caption: 'You, being beautifully you.' },
  { id: 3,  src: photo3,  caption: 'Us, always together.' },
  { id: 4,  src: photo4,  caption: 'My favourite face in the whole world.' },
  { id: 5,  src: photo5,  caption: 'This moment — frozen forever.' },
  { id: 6,  src: photo6,  caption: 'Every day with you is my favourite day.' },
  { id: 7,  src: photo7,  caption: 'You make everything brighter.' },
  { id: 8,  src: photo8,  caption: 'Us, in our own little world.' },
  { id: 9,  src: photo9,  caption: 'That adorable smile, always.' },
  { id: 10, src: photo10, caption: 'You are absolutely stunning.' },
  { id: 11, src: photo11, caption: 'So pretty, it takes my breath away.' },
  { id: 12, src: photo12, caption: 'Every second with you is precious.' },
];

// Ken Burns: each slide gets a unique slow pan direction so it never repeats
const KEN_BURNS = [
  { scale: 1.10, x:  8, y: -6  },
  { scale: 1.08, x: -8, y:  5  },
  { scale: 1.12, x:  5, y:  8  },
  { scale: 1.09, x: -6, y: -8  },
  { scale: 1.11, x:  6, y:  6  },
  { scale: 1.10, x: -5, y: -5  },
  { scale: 1.08, x:  8, y:  4  },
  { scale: 1.12, x: -8, y: -4  },
  { scale: 1.09, x:  4, y: -8  },
  { scale: 1.10, x: -4, y:  8  },
  { scale: 1.11, x:  6, y: -6  },
  { scale: 1.08, x: -6, y:  6  },
];

const SLIDE_INTERVAL = 4500; // ms

// Floating ambient hearts
const FLOAT_HEARTS = Array.from({ length: 8 }, (_, i) => ({
  id: i,
  left:     `${8 + i * 12}%`,
  size:     8 + (i % 3) * 4,
  delay:    i * 0.9,
  duration: 6 + (i % 4) * 1.2,
  opacity:  0.25 + (i % 3) * 0.1,
}));

// Slide transition variants — direction-aware
const variants = {
  enter: (d: 1 | -1) => ({
    opacity: 0,
    x: d > 0 ? '6%' : '-6%',
    scale: 0.97,
  }),
  center: { opacity: 1, x: '0%', scale: 1 },
  exit:  (d: 1 | -1) => ({
    opacity: 0,
    x: d > 0 ? '-6%' : '6%',
    scale: 0.97,
  }),
};

// ─────────────────────────────────────────────────────────────────────────────

export default function Stage5Album({ onNext }: { onNext: () => void }) {
  const [index, setIndex]       = useState(0);
  const [dir, setDir]           = useState<1 | -1>(1);
  const [isPlaying, setPlaying] = useState(true);

  const intervalRef  = useRef<ReturnType<typeof setInterval> | null>(null);
  const touchStartX  = useRef<number | null>(null);

  // ── Auto-advance ────────────────────────────────────────────────────────────
  const go = useCallback((d: 1 | -1) => {
    setDir(d);
    setIndex((p) => (p + d + PHOTOS.length) % PHOTOS.length);
  }, []);

  useEffect(() => {
    if (!isPlaying) { if (intervalRef.current) clearInterval(intervalRef.current); return; }
    intervalRef.current = setInterval(() => go(1), SLIDE_INTERVAL);
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [isPlaying, go]);

  const jumpTo = (i: number) => {
    setDir(i > index ? 1 : -1);
    setIndex(i);
  };

  // ── Touch / swipe ───────────────────────────────────────────────────────────
  const onTouchStart = (e: React.TouchEvent) => { touchStartX.current = e.touches[0].clientX; };
  const onTouchEnd   = (e: React.TouchEvent) => {
    if (touchStartX.current === null) return;
    const dx = e.changedTouches[0].clientX - touchStartX.current;
    if (Math.abs(dx) > 40) go(dx < 0 ? 1 : -1);
    touchStartX.current = null;
  };

  const kb = KEN_BURNS[index % KEN_BURNS.length];

  return (
    <motion.div
      initial={{ opacity: 0, filter: 'blur(8px)' }}
      animate={{ opacity: 1, filter: 'blur(0px)' }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.8 }}
      className="relative w-full flex flex-col items-center"
      style={{ minHeight: '100dvh', padding: '20px 16px 16px' }}
    >

      {/* ── Ambient floating hearts ─────────────────────────────────────────── */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
        {FLOAT_HEARTS.map((h) => (
          <motion.div
            key={h.id}
            className="absolute bottom-0"
            style={{ left: h.left }}
            animate={{ y: [0, -480], opacity: [0, h.opacity, h.opacity, 0] }}
            transition={{ duration: h.duration, delay: h.delay, repeat: Infinity, repeatDelay: 3, ease: 'easeOut' }}
          >
            <Heart fill="#f43f5e" stroke="none" style={{ width: h.size, height: h.size, filter: 'drop-shadow(0 0 3px rgba(244,63,94,0.5))' }} />
          </motion.div>
        ))}
      </div>

      {/* ── Title ──────────────────────────────────────────────────────────── */}
      <motion.div
        initial={{ opacity: 0, y: -12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.7 }}
        className="text-center mb-3 shrink-0 relative z-10"
      >
        <h2 className="text-2xl font-serif text-white drop-shadow-lg leading-snug">
          Our Beautiful Memories ❤️
        </h2>
        <p className="mt-1 text-[11px] font-serif italic text-white/50 leading-relaxed">
          Every picture holds a story, every memory holds a piece of my heart.
        </p>
      </motion.div>

      {/* ── Counter pill ───────────────────────────────────────────────────── */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4, duration: 0.6 }}
        className="mb-2.5 shrink-0 relative z-10 flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/30 backdrop-blur-md border border-white/10"
      >
        <AnimatePresence mode="wait">
          <motion.span
            key={index}
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.22 }}
            className="text-white/80 text-xs font-mono tracking-widest"
          >
            {String(index + 1).padStart(2, '0')}
          </motion.span>
        </AnimatePresence>
        <span className="text-white/30 text-xs font-mono">/</span>
        <span className="text-white/40 text-xs font-mono tracking-widest">
          {String(PHOTOS.length).padStart(2, '0')}
        </span>
      </motion.div>

      {/* ── Photo card ─────────────────────────────────────────────────────── */}
      <div
        className="relative z-10 w-full shrink-0"
        style={{ flex: '1 1 auto', minHeight: 0, maxWidth: 420 }}
        onTouchStart={onTouchStart}
        onTouchEnd={onTouchEnd}
      >
        <AnimatePresence mode="wait" custom={dir}>
          <motion.div
            key={index}
            custom={dir}
            variants={variants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{ duration: 0.55, ease: [0.25, 0.46, 0.45, 0.94] }}
            className="absolute inset-0 rounded-3xl overflow-hidden"
            style={{
              boxShadow: '0 12px 60px rgba(0,0,0,0.7), 0 0 0 1px rgba(255,255,255,0.07)',
            }}
          >
            {/* Ken Burns image */}
            <motion.img
              src={PHOTOS[index].src}
              alt={PHOTOS[index].caption}
              className="absolute inset-0 w-full h-full object-cover"
              initial={{ scale: 1, x: 0, y: 0 }}
              animate={{ scale: kb.scale, x: kb.x, y: kb.y }}
              transition={{ duration: SLIDE_INTERVAL / 1000 + 1.2, ease: 'linear' }}
              draggable={false}
            />

            {/* Top progress bar */}
            {isPlaying && (
              <div className="absolute top-0 inset-x-0 h-[2.5px] bg-white/10 z-20">
                <motion.div
                  key={`pb-${index}`}
                  className="h-full"
                  style={{ background: 'linear-gradient(90deg, rgba(244,63,94,0.8), rgba(251,146,60,0.6))', transformOrigin: 'left' }}
                  initial={{ scaleX: 0 }}
                  animate={{ scaleX: 1 }}
                  transition={{ duration: SLIDE_INTERVAL / 1000, ease: 'linear' }}
                />
              </div>
            )}

            {/* Bottom gradient + caption */}
            <div className="absolute bottom-0 inset-x-0 z-10" style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.80) 0%, rgba(0,0,0,0.35) 55%, transparent 100%)', padding: '32px 20px 20px' }}>
              <AnimatePresence mode="wait">
                <motion.p
                  key={`cap-${index}`}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -6 }}
                  transition={{ duration: 0.45, delay: 0.18 }}
                  className="text-white/90 text-sm font-serif italic text-center leading-snug"
                  style={{ textShadow: '0 1px 8px rgba(0,0,0,0.8)' }}
                >
                  "{PHOTOS[index].caption}"
                </motion.p>
              </AnimatePresence>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* ── Controls ───────────────────────────────────────────────────────── */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5, duration: 0.6 }}
        className="shrink-0 relative z-10 flex flex-col items-center gap-2.5 mt-3"
      >
        {/* Prev / Dots / Next */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => go(-1)}
            className="p-2.5 rounded-full bg-black/35 backdrop-blur-md border border-white/10 hover:bg-white/10 active:scale-90 transition-all"
            aria-label="Previous photo"
          >
            <ChevronLeft className="w-5 h-5 text-white/80" />
          </button>

          {/* Dot indicators */}
          <div className="flex items-center gap-1.5 flex-wrap justify-center" style={{ maxWidth: 200 }}>
            {PHOTOS.map((_, i) => (
              <button
                key={i}
                onClick={() => jumpTo(i)}
                aria-label={`Go to photo ${i + 1}`}
                className={`rounded-full transition-all duration-300 ${
                  i === index
                    ? 'w-5 h-1.5 bg-primary shadow-[0_0_8px_rgba(225,29,72,0.8)]'
                    : 'w-1.5 h-1.5 bg-white/22 hover:bg-white/50'
                }`}
              />
            ))}
          </div>

          <button
            onClick={() => go(1)}
            className="p-2.5 rounded-full bg-black/35 backdrop-blur-md border border-white/10 hover:bg-white/10 active:scale-90 transition-all"
            aria-label="Next photo"
          >
            <ChevronRight className="w-5 h-5 text-white/80" />
          </button>
        </div>

        {/* Play / Pause */}
        <button
          onClick={() => setPlaying((p) => !p)}
          className="flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-black/25 backdrop-blur-md border border-white/10 text-white/45 hover:text-white/75 transition-colors text-[11px] tracking-wide"
        >
          {isPlaying
            ? <><Pause className="w-3 h-3" /> Auto-playing</>
            : <><Play  className="w-3 h-3" /> Paused</>
          }
        </button>
      </motion.div>

      {/* ── Next section button ─────────────────────────────────────────────── */}
      <motion.button
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7, duration: 0.6 }}
        whileHover={{ scale: 1.04 }}
        whileTap={{ scale: 0.96 }}
        onClick={onNext}
        className="shrink-0 relative z-10 flex items-center gap-2 px-8 py-3 mt-3 rounded-full text-white font-medium text-sm transition-all"
        style={{
          background: 'linear-gradient(135deg, rgba(225,29,72,0.80) 0%, rgba(190,18,60,0.80) 100%)',
          border: '1px solid rgba(244,63,94,0.30)',
          boxShadow: '0 4px 24px rgba(225,29,72,0.35)',
          backdropFilter: 'blur(12px)',
        }}
      >
        <span>One Last Thing... ❤️</span>
        <ArrowRight className="w-4 h-4" />
      </motion.button>

    </motion.div>
  );
}
