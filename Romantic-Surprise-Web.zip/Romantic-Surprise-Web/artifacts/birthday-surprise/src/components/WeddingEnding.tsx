import { useEffect, useId, useState, type CSSProperties, type JSX } from 'react';
import { useReducedMotion } from 'framer-motion';

const TEMPLE_IMAGE =
  'https://upload.wikimedia.org/wikipedia/commons/7/76/Triyuginarayan_Temple_-_OCT_2014_Pic2.JPG';

const PETALS = Array.from({ length: 18 }, (_, index) => ({
  left: `${4 + ((index * 37) % 92)}%`,
  delay: `${-((index * 0.53) % 8)}s`,
  duration: `${10 + (index % 5) * 1.4}s`,
  size: `${10 + (index % 4) * 3}px`,
  drift: `${((index % 7) - 3) * 18}px`,
}));

const FLOATING_HEARTS = Array.from({ length: 8 }, (_, index) => ({
  left: `${8 + index * 12}%`,
  delay: `${-((index * 1.17) % 10)}s`,
  duration: `${10 + (index % 3) * 2}s`,
  size: `${11 + (index % 3) * 4}px`,
  drift: `${((index % 5) - 2) * 17}px`,
  offset: `${(index % 4) * 11}vh`,
}));

const GOLDEN_PARTICLES = Array.from({ length: 24 }, (_, index) => ({
  left: `${6 + ((index * 29) % 88)}%`,
  top: `${9 + ((index * 41) % 78)}%`,
  delay: `${(index % 8) * 0.47}s`,
  size: `${2 + (index % 3)}px`,
}));

const SPARKLES = Array.from({ length: 12 }, (_, index) => ({
  left: `${10 + ((index * 43) % 80)}%`,
  top: `${12 + ((index * 31) % 72)}%`,
  delay: `${(index % 6) * 0.6}s`,
}));

export default function WeddingEnding(): JSX.Element {
  const reducedMotion = useReducedMotion();
  const [step, setStep] = useState(reducedMotion ? 6 : 0);
  const ringGradientId = `wedding-gold-${useId().replace(/:/g, '')}`;

  useEffect(() => {
    if (reducedMotion) {
      setStep(6);
      return;
    }

    const milestones = [350, 1700, 3000, 3900, 5000, 6100];
    const timers = milestones.map((delay, index) =>
      window.setTimeout(() => setStep(index + 1), delay),
    );

    return () => timers.forEach(window.clearTimeout);
  }, [reducedMotion]);

  return (
    <section
      className="wedding-ending"
      aria-label="A promise at Triyuginarayan Temple"
      data-testid="section-wedding-ending"
    >
      <style>{`
        .wedding-ending {
          position: fixed;
          z-index: 80;
          inset: 0;
          display: flex;
          width: 100vw;
          min-height: 100dvh;
          align-items: center;
          justify-content: center;
          overflow-x: hidden;
          overflow-y: auto;
          overscroll-behavior: contain;
          isolation: isolate;
          padding: 0;
          color: #fff7f6;
          background: #100b0b;
          text-align: center;
          animation: wedding-screen-in 1.35s ease-out both;
        }
        .wedding-ending, .wedding-ending * { box-sizing: border-box; }
        .wedding-temple-backdrop {
          position: fixed;
          z-index: 0;
          inset: 0;
          background-image: url("${TEMPLE_IMAGE}");
          background-attachment: fixed;
          background-position: center 48%;
          background-repeat: no-repeat;
          background-size: cover;
          opacity: 0;
          transform: scale(1.025);
          animation: wedding-temple-reveal 2.4s ease-out .1s forwards;
          will-change: opacity, transform;
        }
        .wedding-ending::before {
          position: absolute;
          z-index: 1;
          inset: 0;
          content: "";
          pointer-events: none;
          background:
            linear-gradient(180deg, rgba(10, 8, 8, .25) 0%, rgba(9, 6, 8, .44) 44%, rgba(8, 5, 7, .64) 100%),
            radial-gradient(ellipse at 50% 42%, rgba(78, 40, 41, .16), transparent 66%);
        }
        .wedding-mandap {
          position: absolute;
          z-index: 2;
          top: 50%;
          left: 50%;
          width: min(88vw, 510px);
          height: min(58vh, 390px);
          transform: translate(-50%, -50%);
          opacity: 0;
          pointer-events: none;
        }
        .wedding-mandap.is-visible { animation: wedding-mandap-in 1.7s ease-out forwards; }
        .wedding-mandap svg { width: 100%; height: 100%; overflow: visible; }
        .wedding-mandap-arch {
          fill: none;
          stroke: rgba(255, 222, 171, .5);
          stroke-width: 1.35;
          stroke-linecap: round;
          filter: drop-shadow(0 0 5px rgba(250, 193, 119, .34));
        }
        .wedding-flower {
          fill: rgba(255, 186, 199, .72);
          stroke: rgba(255, 237, 204, .82);
          stroke-width: 1.1;
          filter: drop-shadow(0 0 5px rgba(255, 194, 192, .36));
        }
        .wedding-atmosphere {
          position: absolute;
          z-index: 3;
          inset: 0;
          overflow: hidden;
          opacity: 0;
          pointer-events: none;
          transition: opacity 1.2s ease;
        }
        .wedding-atmosphere.is-active { opacity: 1; }
        .wedding-fireglow {
          position: absolute;
          bottom: 2vh;
          left: 50%;
          width: min(42vw, 240px);
          height: 140px;
          transform: translateX(-50%);
          border-radius: 50%;
          background:
            radial-gradient(ellipse at 50% 75%, rgba(255, 157, 59, .35), transparent 68%),
            radial-gradient(ellipse at 50% 90%, rgba(255, 210, 124, .22), transparent 48%);
          filter: blur(8px);
          opacity: .8;
          animation: wedding-fire-warmth 4.5s ease-in-out infinite alternate;
          animation-play-state: paused;
        }
        .wedding-atmosphere.is-active .wedding-fireglow { animation-play-state: running; }
        .wedding-petal {
          position: absolute;
          top: -14vh;
          display: block;
          width: var(--petal-size);
          height: calc(var(--petal-size) * 1.42);
          border: 1px solid rgba(255, 228, 220, .45);
          border-radius: 70% 12% 68% 18%;
          background: linear-gradient(145deg, rgba(255, 205, 211, .9), rgba(204, 88, 107, .84));
          box-shadow: 0 0 14px rgba(244, 146, 154, .22);
          opacity: 0;
          animation: wedding-petal-fall var(--fall-duration) linear var(--fall-delay) infinite;
          animation-play-state: paused;
          will-change: transform, opacity;
        }
        .wedding-atmosphere.is-active .wedding-petal { animation-play-state: running; }
        .wedding-heart {
          position: absolute;
          bottom: -48px;
          color: rgba(255, 201, 214, .56);
          font-size: var(--heart-size);
          text-shadow: 0 0 14px rgba(255, 178, 199, .45);
          opacity: 0;
          animation: wedding-heart-rise var(--heart-duration) ease-in var(--heart-delay) infinite;
          animation-play-state: paused;
          will-change: transform, opacity;
        }
        .wedding-atmosphere.is-active .wedding-heart { animation-play-state: running; }
        .wedding-golden-particle {
          position: absolute;
          width: var(--particle-size);
          height: var(--particle-size);
          border-radius: 50%;
          background: #ffe5a8;
          box-shadow: 0 0 8px 2px rgba(255, 211, 131, .52);
          opacity: 0;
          animation: wedding-golden-twinkle 3.8s ease-in-out var(--particle-delay) infinite;
          animation-play-state: paused;
        }
        .wedding-atmosphere.is-active .wedding-golden-particle { animation-play-state: running; }
        .wedding-sparkle {
          position: absolute;
          color: rgba(255, 245, 214, .9);
          font-size: 13px;
          text-shadow: 0 0 12px rgba(255, 224, 165, .78);
          opacity: 0;
          animation: wedding-sparkle 3.6s ease-in-out var(--sparkle-delay) infinite;
          animation-play-state: paused;
        }
        .wedding-atmosphere.is-active .wedding-sparkle { animation-play-state: running; }
        .wedding-content {
          position: relative;
          z-index: 5;
          display: flex;
          width: min(100%, 960px);
          min-height: 100dvh;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          gap: clamp(5px, 1.1vh, 13px);
          padding: clamp(22px, 5vh, 54px) 20px clamp(52px, 8vh, 76px);
          opacity: 0;
          transform: translateY(10px);
          animation: wedding-copy-arrive 1.25s ease-out .2s forwards;
        }
        .wedding-rings {
          display: block;
          width: min(72vw, 290px);
          height: clamp(118px, 21vh, 172px);
          flex: 0 0 auto;
          overflow: visible;
          opacity: 0;
          transform: scale(.94);
          filter: drop-shadow(0 0 14px rgba(255, 209, 123, .42));
        }
        .wedding-rings.is-visible { animation: wedding-rings-appear 1.6s ease-out forwards; }
        .wedding-ring-band {
          fill: rgba(255, 216, 143, .04);
          stroke: url(#${ringGradientId});
          stroke-width: 8;
        }
        .wedding-ring-highlight {
          fill: none;
          stroke: rgba(255, 249, 224, .9);
          stroke-width: 1.3;
          opacity: .72;
        }
        .wedding-ring-stone {
          fill: #fff8df;
          stroke: rgba(255, 222, 156, .95);
          stroke-width: 1.3;
          filter: drop-shadow(0 0 5px rgba(255, 231, 175, .8));
        }
        .wedding-ring-one, .wedding-ring-two {
          opacity: 0;
        }
        .wedding-rings.is-visible .wedding-ring-one {
          animation: wedding-ring-left 1.55s cubic-bezier(.2,.75,.25,1) .16s forwards;
        }
        .wedding-rings.is-visible .wedding-ring-two {
          animation: wedding-ring-right 1.55s cubic-bezier(.2,.75,.25,1) .16s forwards;
        }
        .wedding-promise {
          display: flex;
          width: min(100%, 820px);
          flex-direction: column;
          align-items: center;
          gap: clamp(4px, 1vh, 12px);
          margin: 0;
          font-family: 'Playfair Display', Georgia, serif;
          color: #fff7f6;
          text-shadow: 0 2px 22px rgba(0, 0, 0, .72), 0 0 22px rgba(248, 189, 207, .19);
        }
        .wedding-promise-line {
          max-width: 100%;
          margin: 0;
          font-size: clamp(19px, 3.1vw, 31px);
          font-weight: 400;
          line-height: 1.48;
          letter-spacing: .015em;
          text-wrap: pretty;
          opacity: 0;
          transform: translateY(12px);
          filter: blur(5px);
        }
        .wedding-promise-line.is-visible {
          animation: wedding-line-reveal 1.05s cubic-bezier(.2,.7,.25,1) forwards;
        }
        .wedding-forever {
          margin: clamp(5px, 1.4vh, 16px) 0 0;
          color: #f8d9e3;
          font-size: clamp(16px, 2.5vw, 22px);
          font-style: italic;
          letter-spacing: .04em;
          opacity: 0;
          transform: translateY(10px);
          filter: blur(4px);
        }
        .wedding-forever.is-visible {
          animation: wedding-line-reveal 1s cubic-bezier(.2,.7,.25,1) forwards;
        }
        .wedding-signature {
          margin: 0;
          color: #ffe0e9;
          font-family: 'Great Vibes', cursive;
          font-size: clamp(29px, 5.6vw, 48px);
          font-weight: 400;
          line-height: 1.25;
          text-shadow: 0 0 26px rgba(255, 193, 215, .3);
          opacity: 0;
          transform: translateY(10px);
          filter: blur(4px);
        }
        .wedding-signature.is-visible {
          animation: wedding-line-reveal 1.2s cubic-bezier(.2,.7,.25,1) forwards;
        }
        .wedding-photo-credit {
          position: fixed;
          z-index: 6;
          right: 12px;
          bottom: 10px;
          left: 12px;
          margin: 0;
          color: rgba(255, 246, 231, .68);
          font: 11px/1.4 'Playfair Display', Georgia, serif;
          text-shadow: 0 1px 8px rgba(0, 0, 0, .75);
        }
        .wedding-photo-credit a {
          color: inherit;
          text-decoration-color: rgba(255, 246, 231, .48);
          text-underline-offset: 2px;
        }
        @keyframes wedding-screen-in {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes wedding-temple-reveal {
          from { opacity: 0; transform: scale(1.035); }
          to { opacity: 1; transform: scale(1); }
        }
        @keyframes wedding-mandap-in {
          from { opacity: 0; }
          to { opacity: .34; }
        }
        @keyframes wedding-fire-warmth {
          from { opacity: .52; transform: translateX(-50%) scale(.96); }
          to { opacity: .88; transform: translateX(-50%) scale(1.04); }
        }
        @keyframes wedding-petal-fall {
          0% { opacity: 0; transform: translate3d(0, -3vh, 0) rotate(0deg); }
          10% { opacity: .72; }
          88% { opacity: .56; }
          100% { opacity: 0; transform: translate3d(var(--petal-drift), 114vh, 0) rotate(500deg); }
        }
        @keyframes wedding-heart-rise {
          0% { opacity: 0; transform: translate3d(0, 0, 0) scale(.72); }
          16% { opacity: .55; }
          82% { opacity: .42; }
          100% { opacity: 0; transform: translate3d(var(--heart-drift), -112vh, 0) scale(1.12); }
        }
        @keyframes wedding-golden-twinkle {
          0%, 100% { opacity: .12; transform: scale(.65); }
          50% { opacity: .8; transform: scale(1.25); }
        }
        @keyframes wedding-sparkle {
          0%, 100% { opacity: .12; transform: scale(.72) rotate(0deg); }
          50% { opacity: .82; transform: scale(1.18) rotate(18deg); }
        }
        @keyframes wedding-rings-appear {
          from { opacity: 0; transform: translateY(12px) scale(.92); }
          to { opacity: 1; transform: translateY(0) scale(1); }
        }
        @keyframes wedding-ring-left {
          0% { opacity: 0; transform: translateX(-46px); }
          72% { opacity: 1; transform: translateX(-5px); }
          100% { opacity: 1; transform: translateX(-10px); }
        }
        @keyframes wedding-ring-right {
          0% { opacity: 0; transform: translateX(46px); }
          72% { opacity: 1; transform: translateX(5px); }
          100% { opacity: 1; transform: translateX(10px); }
        }
        @keyframes wedding-line-reveal {
          from { opacity: 0; transform: translateY(12px); filter: blur(5px); }
          to { opacity: 1; transform: translateY(0); filter: blur(0); }
        }
        @keyframes wedding-copy-arrive {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @media (max-height: 650px) {
          .wedding-content {
            gap: 3px;
            padding-top: 14px;
            padding-bottom: 36px;
          }
          .wedding-rings { height: 106px; }
          .wedding-promise-line { font-size: clamp(18px, 2.8vw, 25px); line-height: 1.36; }
          .wedding-forever { margin-top: 5px; }
          .wedding-signature { font-size: clamp(27px, 4vw, 38px); }
        }
        @media (max-width: 520px) {
          .wedding-temple-backdrop { background-position: 46% center; }
          .wedding-ending::before {
            background:
              linear-gradient(180deg, rgba(10, 8, 8, .3) 0%, rgba(9, 6, 8, .48) 44%, rgba(8, 5, 7, .68) 100%),
              radial-gradient(ellipse at 50% 42%, rgba(78, 40, 41, .13), transparent 66%);
          }
          .wedding-content {
            gap: 4px;
            padding: 16px 16px 42px;
          }
          .wedding-rings { height: clamp(112px, 17vh, 144px); }
          .wedding-promise { gap: 4px; }
          .wedding-promise-line { font-size: clamp(19px, 5.4vw, 26px); }
          .wedding-mandap { width: 94vw; height: 48vh; }
        }
        @media (prefers-reduced-motion: reduce) {
          .wedding-ending,
          .wedding-temple-backdrop,
          .wedding-mandap.is-visible,
          .wedding-rings.is-visible,
          .wedding-promise-line.is-visible,
          .wedding-forever.is-visible,
          .wedding-signature.is-visible,
          .wedding-content,
          .wedding-fireglow,
          .wedding-petal,
          .wedding-heart,
          .wedding-golden-particle,
          .wedding-sparkle {
            animation: none !important;
            transition: none !important;
          }
          .wedding-temple-backdrop { opacity: 1; transform: none; }
          .wedding-mandap.is-visible { opacity: .34; }
          .wedding-content { opacity: 1; transform: none; }
          .wedding-rings.is-visible { opacity: 1; transform: none; }
          .wedding-rings.is-visible .wedding-ring-one {
            opacity: 1;
            transform: translateX(-10px);
          }
          .wedding-rings.is-visible .wedding-ring-two {
            opacity: 1;
            transform: translateX(10px);
          }
          .wedding-promise-line.is-visible,
          .wedding-forever.is-visible,
          .wedding-signature.is-visible {
            opacity: 1;
            transform: none;
            filter: none;
          }
          .wedding-petal { top: 18%; opacity: .24; }
          .wedding-heart { bottom: 24%; opacity: .42; }
          .wedding-golden-particle, .wedding-sparkle { opacity: .46; }
          .wedding-fireglow { opacity: .58; }
        }
      `}</style>

      <div className="wedding-temple-backdrop" aria-hidden="true" />

      <div
        className={`wedding-mandap${step >= 1 ? ' is-visible' : ''}`}
        aria-hidden="true"
      >
        <svg viewBox="0 0 360 250" role="presentation">
          <path className="wedding-mandap-arch" d="M35 233 V133 C35 72 91 27 180 27 C269 27 325 72 325 133 V233" />
          <path className="wedding-mandap-arch" d="M53 233 V143 C53 90 103 49 180 49 C257 49 307 90 307 143 V233" />
          <path className="wedding-mandap-arch" d="M26 132 C73 91 107 78 180 78 C253 78 287 91 334 132" />
          <g>
            <circle className="wedding-flower" cx="35" cy="126" r="6" />
            <circle className="wedding-flower" cx="57" cy="108" r="5" />
            <circle className="wedding-flower" cx="82" cy="91" r="5" />
            <circle className="wedding-flower" cx="111" cy="78" r="4.5" />
            <circle className="wedding-flower" cx="145" cy="70" r="5" />
            <circle className="wedding-flower" cx="180" cy="68" r="6" />
            <circle className="wedding-flower" cx="215" cy="70" r="5" />
            <circle className="wedding-flower" cx="249" cy="78" r="4.5" />
            <circle className="wedding-flower" cx="278" cy="91" r="5" />
            <circle className="wedding-flower" cx="303" cy="108" r="5" />
            <circle className="wedding-flower" cx="325" cy="126" r="6" />
          </g>
        </svg>
      </div>

      <div className={`wedding-atmosphere${step >= 1 ? ' is-active' : ''}`} aria-hidden="true">
        <div className="wedding-fireglow" />
        {PETALS.map((petal, index) => (
          <span
            key={`petal-${index}`}
            className="wedding-petal"
            style={{
              left: petal.left,
              ['--petal-size' as string]: petal.size,
              ['--petal-drift' as string]: petal.drift,
              ['--fall-delay' as string]: petal.delay,
              ['--fall-duration' as string]: petal.duration,
            } as CSSProperties}
          />
        ))}
        {FLOATING_HEARTS.map((heart, index) => (
          <span
            key={`heart-${index}`}
            className="wedding-heart"
            style={{
              left: heart.left,
              ['--heart-size' as string]: heart.size,
              ['--heart-drift' as string]: heart.drift,
              ['--heart-delay' as string]: heart.delay,
              ['--heart-duration' as string]: heart.duration,
              ['--heart-offset' as string]: heart.offset,
            } as CSSProperties}
          >
            ♥
          </span>
        ))}
        {GOLDEN_PARTICLES.map((particle, index) => (
          <i
            key={`gold-${index}`}
            className="wedding-golden-particle"
            style={{
              left: particle.left,
              top: particle.top,
              ['--particle-size' as string]: particle.size,
              ['--particle-delay' as string]: particle.delay,
            } as CSSProperties}
          />
        ))}
        {SPARKLES.map((sparkle, index) => (
          <i
            key={`sparkle-${index}`}
            className="wedding-sparkle"
            style={{
              left: sparkle.left,
              top: sparkle.top,
              ['--sparkle-delay' as string]: sparkle.delay,
            } as CSSProperties}
          >
            ✦
          </i>
        ))}
      </div>

      <div className="wedding-content">
        <svg
          className={`wedding-rings${step >= 2 ? ' is-visible' : ''}`}
          viewBox="0 0 260 156"
          role="img"
          aria-label="Two golden wedding rings gently meeting"
          data-testid="wedding-rings"
        >
          <defs>
            <linearGradient id={ringGradientId} x1="0" y1="0" x2="1" y2="1">
              <stop offset="0" stopColor="#fff4ce" />
              <stop offset=".42" stopColor="#e8bd6b" />
              <stop offset=".72" stopColor="#fff1be" />
              <stop offset="1" stopColor="#bd8340" />
            </linearGradient>
          </defs>
          <g className="wedding-ring-one">
            <ellipse className="wedding-ring-band" cx="100" cy="80" rx="34" ry="44" />
            <ellipse className="wedding-ring-highlight" cx="100" cy="80" rx="27" ry="36" />
            <path className="wedding-ring-stone" d="M100 26 L106 33 L100 40 L94 33 Z" />
          </g>
          <g className="wedding-ring-two">
            <ellipse className="wedding-ring-band" cx="160" cy="80" rx="34" ry="44" />
            <ellipse className="wedding-ring-highlight" cx="160" cy="80" rx="27" ry="36" />
            <path className="wedding-ring-stone" d="M160 26 L166 33 L160 40 L154 33 Z" />
          </g>
        </svg>

        <div className="wedding-promise" aria-live="polite">
          <p
            className={`wedding-promise-line${step >= 3 ? ' is-visible' : ''}`}
            data-testid="promise-line-one"
          >
            Once you let me hold your hand,
          </p>
          <p
            className={`wedding-promise-line${step >= 4 ? ' is-visible' : ''}`}
            data-testid="promise-line-two"
          >
            I’ll never let it go until my last breath. ❤️
          </p>
          <p
            className={`wedding-forever${step >= 5 ? ' is-visible' : ''}`}
            data-testid="promise-forever"
          >
            Forever yours,
          </p>
          <p
            className={`wedding-signature${step >= 6 ? ' is-visible' : ''}`}
            data-testid="promise-signature"
          >
            Bobby — nee future moguduu 😌💍❤️🐢
          </p>
        </div>
      </div>

      <p className="wedding-photo-credit">
        Temple photo:{' '}
        <a
          href="https://commons.wikimedia.org/wiki/File:Triyuginarayan_Temple_-_OCT_2014_Pic2.JPG"
          target="_blank"
          rel="noreferrer"
        >
          Naresh Balakrishnan · CC BY-SA 4.0
        </a>
      </p>
    </section>
  );
}
