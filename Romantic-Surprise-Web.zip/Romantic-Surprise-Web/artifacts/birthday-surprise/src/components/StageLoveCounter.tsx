import React, { useEffect, useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart } from 'lucide-react';

// ─── Start date of the relationship ──────────────────────────────────────────
const START_DATE = new Date('2025-05-10T00:00:00');

interface TimeElapsed {
  years: number;
  months: number;
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

function getElapsed(): TimeElapsed {
  const now   = new Date();
  let   years = now.getFullYear() - START_DATE.getFullYear();
  let   months = now.getMonth() - START_DATE.getMonth();
  let   days   = now.getDate()  - START_DATE.getDate();
  let   hours  = now.getHours() - START_DATE.getHours();
  let   mins   = now.getMinutes() - START_DATE.getMinutes();
  let   secs   = now.getSeconds() - START_DATE.getSeconds();

  if (secs < 0)  { secs  += 60; mins--;  }
  if (mins < 0)  { mins  += 60; hours--; }
  if (hours < 0) { hours += 24; days--;  }
  if (days < 0) {
    const prevMonth = new Date(now.getFullYear(), now.getMonth(), 0);
    days  += prevMonth.getDate();
    months--;
  }
  if (months < 0) { months += 12; years--; }

  return { years, months, days, hours, minutes: mins, seconds: secs };
}

// ─── Floating hearts decoration ───────────────────────────────────────────────
const HEARTS = Array.from({ length: 10 }, (_, i) => ({
  id: i,
  size:     Math.random() * 14 + 8,
  left:     `${5 + Math.random() * 90}%`,
  duration: Math.random() * 6 + 7,
  delay:    Math.random() * 8,
  opacity:  Math.random() * 0.4 + 0.15,
}));

function FloatingHeartsBg() {
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden rounded-3xl">
      {HEARTS.map((h) => (
        <motion.div
          key={h.id}
          className="absolute bottom-0"
          style={{ left: h.left }}
          animate={{ y: [0, -340], opacity: [0, h.opacity, h.opacity, 0] }}
          transition={{ duration: h.duration, delay: h.delay, repeat: Infinity, ease: 'easeOut' }}
        >
          <Heart
            fill="#f43f5e"
            stroke="none"
            style={{ width: h.size, height: h.size, filter: 'drop-shadow(0 0 4px rgba(244,63,94,0.6))' }}
          />
        </motion.div>
      ))}
    </div>
  );
}

// ─── Single counter unit ──────────────────────────────────────────────────────
function CountUnit({ value, label }: { value: number; label: string }) {
  const display = String(value).padStart(2, '0');

  return (
    <div className="flex flex-col items-center gap-1">
      {/* Flip card effect — key on value triggers re-mount → re-animation */}
      <AnimatePresence mode="popLayout">
        <motion.div
          key={display}
          initial={{ y: -14, opacity: 0, scale: 0.85 }}
          animate={{ y: 0,   opacity: 1, scale: 1    }}
          exit={{    y:  14, opacity: 0, scale: 0.85  }}
          transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
          className="relative"
        >
          {/* Glow behind number */}
          <div
            className="absolute inset-0 rounded-xl blur-md opacity-40"
            style={{ background: 'radial-gradient(circle, rgba(244,63,94,0.7) 0%, transparent 70%)' }}
          />
          <div
            className="relative px-2.5 py-2 rounded-xl text-center min-w-[48px]"
            style={{
              background: 'rgba(255,255,255,0.07)',
              border: '1px solid rgba(244,63,94,0.25)',
              backdropFilter: 'blur(12px)',
              boxShadow: '0 0 18px rgba(244,63,94,0.12), inset 0 1px 0 rgba(255,255,255,0.08)',
            }}
          >
            <span
              className="block font-serif font-bold text-white leading-none"
              style={{ fontSize: 22, textShadow: '0 0 12px rgba(244,63,94,0.6)' }}
            >
              {display}
            </span>
          </div>
        </motion.div>
      </AnimatePresence>
      <span className="text-[10px] tracking-widest uppercase text-white/50 font-sans">
        {label}
      </span>
    </div>
  );
}

// ─── Separator dot ────────────────────────────────────────────────────────────
function Sep() {
  return (
    <motion.span
      animate={{ opacity: [1, 0.2, 1] }}
      transition={{ duration: 1.2, repeat: Infinity, ease: 'easeInOut' }}
      className="text-primary/60 font-bold self-center mb-4 text-sm"
    >
      :
    </motion.span>
  );
}

// ─────────────────────────────────────────────────────────────────────────────

export default function StageLoveCounter({ onNext }: { onNext: () => void }) {
  const [elapsed, setElapsed] = useState<TimeElapsed>(getElapsed);

  // Tick every second
  useEffect(() => {
    const id = setInterval(() => setElapsed(getElapsed()), 1000);
    return () => clearInterval(id);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.9 }}
      className="w-full flex flex-col items-center justify-center px-5 py-10 gap-8"
    >
      {/* ── Card ──────────────────────────────────────────────────────────── */}
      <motion.div
        initial={{ y: 40, opacity: 0, scale: 0.95 }}
        animate={{ y: 0,  opacity: 1, scale: 1    }}
        transition={{ duration: 1, delay: 0.15, ease: [0.22, 1, 0.36, 1] }}
        className="relative w-full max-w-sm rounded-3xl overflow-hidden"
        style={{
          background: 'rgba(10,4,20,0.55)',
          border: '1px solid rgba(244,63,94,0.22)',
          backdropFilter: 'blur(24px)',
          boxShadow: '0 8px 60px rgba(225,29,72,0.18), 0 2px 0 rgba(255,255,255,0.04) inset',
        }}
      >
        <FloatingHeartsBg />

        {/* Top glow line */}
        <div className="absolute top-0 inset-x-0 h-px" style={{ background: 'linear-gradient(90deg, transparent, rgba(244,63,94,0.55), transparent)' }} />

        <div className="relative z-10 flex flex-col items-center gap-6 px-6 py-8">

          {/* ── Pulsing heart icon ─────────────────────────────────────── */}
          <motion.div
            animate={{ scale: [1, 1.15, 1], filter: ['drop-shadow(0 0 6px rgba(244,63,94,0.5))', 'drop-shadow(0 0 18px rgba(244,63,94,0.9))', 'drop-shadow(0 0 6px rgba(244,63,94,0.5))'] }}
            transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut' }}
          >
            <Heart fill="#f43f5e" stroke="none" className="w-9 h-9" />
          </motion.div>

          {/* ── Title ─────────────────────────────────────────────────── */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="text-center"
          >
            <h2
              className="font-script text-white leading-tight"
              style={{ fontSize: 28, textShadow: '0 0 20px rgba(244,63,94,0.5)', fontFamily: "'Great Vibes', cursive" }}
            >
              Our Love Story Began On ❤️
            </h2>
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.7, duration: 0.8 }}
              className="mt-1.5 text-sm font-serif italic text-primary/80 tracking-wide"
            >
              May 10, 2025
            </motion.p>
          </motion.div>

          {/* ── Counter grid ──────────────────────────────────────────── */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.9 }}
            className="w-full"
          >
            {/* Row 1: Years · Months · Days */}
            <div className="flex items-end justify-center gap-2 mb-4">
              <CountUnit value={elapsed.years}   label="Years"  />
              <Sep />
              <CountUnit value={elapsed.months}  label="Months" />
              <Sep />
              <CountUnit value={elapsed.days}    label="Days"   />
            </div>

            {/* Thin divider */}
            <div className="mx-auto mb-4 h-px w-3/4" style={{ background: 'linear-gradient(90deg, transparent, rgba(244,63,94,0.3), transparent)' }} />

            {/* Row 2: Hours · Minutes · Seconds */}
            <div className="flex items-end justify-center gap-2">
              <CountUnit value={elapsed.hours}   label="Hours"   />
              <Sep />
              <CountUnit value={elapsed.minutes} label="Minutes" />
              <Sep />
              <CountUnit value={elapsed.seconds} label="Seconds" />
            </div>
          </motion.div>

          {/* ── Tagline ───────────────────────────────────────────────── */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.1, duration: 1 }}
            className="text-center text-xs font-serif italic text-white/40 leading-relaxed"
          >
            Every second with you is a treasure ❤️
          </motion.p>
        </div>

        {/* Bottom glow line */}
        <div className="absolute bottom-0 inset-x-0 h-px" style={{ background: 'linear-gradient(90deg, transparent, rgba(244,63,94,0.35), transparent)' }} />
      </motion.div>

      {/* ── Continue button ────────────────────────────────────────────────── */}
      <motion.button
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.4, duration: 0.8 }}
        whileHover={{ scale: 1.04 }}
        whileTap={{ scale: 0.96 }}
        onClick={onNext}
        className="flex items-center gap-2 px-8 py-3 rounded-full text-sm font-serif tracking-wide text-white transition-all"
        style={{
          background: 'linear-gradient(135deg, rgba(225,29,72,0.75) 0%, rgba(190,18,60,0.75) 100%)',
          border: '1px solid rgba(244,63,94,0.35)',
          boxShadow: '0 4px 24px rgba(225,29,72,0.35)',
          backdropFilter: 'blur(12px)',
        }}
      >
        <Heart fill="currentColor" stroke="none" className="w-3.5 h-3.5" />
        <span>See Our Memories</span>
      </motion.button>
    </motion.div>
  );
}
