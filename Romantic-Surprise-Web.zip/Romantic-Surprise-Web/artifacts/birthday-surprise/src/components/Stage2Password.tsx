import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Lock } from 'lucide-react';

export default function Stage2Password({ onNext }: { onNext: () => void }) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState(false);

  // CHANGE PASSWORD HERE — password is '2311'
  const CORRECT_PASSWORD = '2311';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === CORRECT_PASSWORD) {
      setError(false);
      onNext();
    } else {
      setError(true);
      setPassword('');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, y: -20, filter: "blur(10px)" }}
      transition={{ duration: 0.8 }}
      className="flex flex-col items-center justify-center space-y-8 w-full max-w-sm glass-panel p-10 rounded-[2rem] mx-4"
    >
      <div className="bg-primary/10 p-5 rounded-full border border-primary/20 shadow-[0_0_20px_rgba(225,29,72,0.1)]">
        <Lock className="w-8 h-8 text-primary opacity-80" />
      </div>
      
      <div className="space-y-2 text-center">
        <h2 className="text-2xl font-serif text-white">For your eyes only</h2>
        <p className="text-sm text-white/50 italic font-serif">
          Enter the magic numbers to unlock...
        </p>
      </div>

      <form onSubmit={handleSubmit} className="w-full space-y-8 flex flex-col items-center">
        <div className="space-y-2 w-full">
          <input
            type="password"
            inputMode="numeric"
            value={password}
            onChange={(e) => {
              setPassword(e.target.value);
              if (error) setError(false);
            }}
            placeholder="••••"
            className="w-full bg-black/30 border-b-2 border-primary/30 focus:border-primary px-4 py-4 text-center text-3xl font-mono text-white focus:outline-none transition-colors tracking-[1em] placeholder:text-white/10 placeholder:tracking-widest rounded-t-lg"
            autoFocus
          />
        </div>
        
        <div className="h-6 flex items-center justify-center w-full">
          <AnimatePresence mode="wait">
            {error && (
              <motion.p
                initial={{ opacity: 0, y: -5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="text-primary text-sm font-medium"
              >
                Hmm, that doesn't seem right... try again
              </motion.p>
            )}
          </AnimatePresence>
        </div>

        <button
          type="submit"
          disabled={password.length === 0}
          className="px-10 py-3 bg-primary text-white rounded-full font-medium disabled:opacity-30 disabled:cursor-not-allowed transition-all hover:bg-primary/90 hover:scale-105 active:scale-95 shadow-[0_0_15px_rgba(225,29,72,0.3)]"
        >
          Unlock
        </button>
      </form>
    </motion.div>
  );
}