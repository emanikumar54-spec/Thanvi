import React, { useEffect } from 'react';
import { motion } from 'framer-motion';

export default function Stage3Intro({ onNext }: { onNext: () => void }) {
  useEffect(() => {
    const timer = setTimeout(() => {
      onNext();
    }, 4000);
    return () => clearTimeout(timer);
  }, [onNext]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 1.05 }}
      transition={{ duration: 1.5 }}
      className="flex flex-col items-center justify-center text-center space-y-6 h-full w-full"
    >
      <motion.p 
        initial={{ opacity: 0, y: 10, filter: "blur(5px)" }}
        animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
        transition={{ delay: 0.5, duration: 1.5, ease: "easeOut" }}
        className="text-2xl font-serif italic text-white/90 tracking-wide"
      >
        Unlocking our memories...
      </motion.p>
      
      <motion.div 
        className="w-[1px] h-16 bg-gradient-to-b from-primary/80 to-transparent"
        initial={{ scaleY: 0, originY: 0 }}
        animate={{ scaleY: 1 }}
        transition={{ delay: 1.5, duration: 1.5, ease: "easeInOut" }}
      />
    </motion.div>
  );
}