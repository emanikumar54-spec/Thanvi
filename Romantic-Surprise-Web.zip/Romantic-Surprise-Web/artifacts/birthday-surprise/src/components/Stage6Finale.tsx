import React, { useEffect, useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Fireworks from './Fireworks';
import { Heart } from 'lucide-react';

// ─── Messages shown one by one ────────────────────────────────────────────────
const MESSAGES = [
  { text: 'I have something to tell you... ❤️',                  size: 'lg',  italic: true  },
  { text: 'You are the best thing that ever happened to me.',     size: 'base', italic: false },
  { text: 'Every smile of yours makes my world brighter.',        size: 'base', italic: false },
  { text: 'No matter where life takes us...',                     size: 'base', italic: true  },
  { text: "I'll always cherish every moment we created together.", size: 'base', italic: false },
];

// After these 5, "I Love You" triggers fireworks, then 2 more appear
const LOVE_MSG   = 'I Love You So Much ❤️';
const BDAY_MSG   = 'Happy Birthday, My Love 🎂❤️';
const SIGN_MSG   = 'Forever Yours,\nBobby ❤️';

// Phase timing (ms after mount)
const PHASE_TIMES = [
  800,    // phase 0 → show msg[0]
  4200,   // phase 1 → msg[1]
  7600,   // phase 2 → msg[2]
  11000,  // phase 3 → msg[3]
  14400,  // phase 4 → msg[4]
  17800,  // phase 5 → I Love You + fireworks
  22500,  // phase 6 → Happy Birthday
  26000,  // phase 7 → Forever Yours + replay
];

// ─── Floating hearts rain ─────────────────────────────────────────────────────
const HEART_COUNT = 60;

function FloatingHearts() {
  const hearts = useMemo(() =>
    Array.from({ length: HEART_COUNT }, (_, i) => ({
      id: i,
      left:     `${Math.random() * 100}%`,
      size:     Math.random() * 18 + 8,
      duration: Math.random() * 5 + 5,
      delay:    Math.random() * 6,
      opacity:  Math.random() * 0.55 + 0.2,
      drift:    (Math.random() - 0.5) * 60,
    })),
  []);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden" style={{ zIndex: 4 }}>
      {hearts.map((h) => (
        <motion.div
          key={h.id}
          className="absolute bottom-0"
          style={{ left: h.left }}
          initial={{ y: 0, opacity: 0, x: 0 }}
          animate={{
            y: [0, -window.innerHeight - 60],
            opacity: [0, h.opacity, h.opacity, 0],
            x: [0, h.drift, -h.drift * 0.4],
          }}
          transition={{
            duration: h.duration,
            delay: h.delay,
            repeat: Infinity,
            repeatDelay: Math.random() * 3,
            ease: 'easeOut',
          }}
        >
          <svg
            width={h.size} height={h.size}
            viewBox="0 0 24 24"
            fill="#f43f5e"
            style={{ filter: 'drop-shadow(0 0 4px rgba(244,63,94,0.7))' }}
          >
            <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
          </svg>
        </motion.div>
      ))}
    </div>
  );
}

// ─── Glowing radial particles overlay ────────────────────────────────────────
const GLOW_COUNT = 20;
function GlowParticles() {
  const dots = useMemo(() =>
    Array.from({ length: GLOW_COUNT }, (_, i) => ({
      id: i,
      left: `${Math.random() * 100}%`,
      top:  `${Math.random() * 100}%`,
      size: Math.random() * 6 + 3,
      dur:  Math.random() * 3 + 2,
      del:  Math.random() * 4,
      color: ['#f43f5e', '#fda4af', '#fbbf24', '#fff'][Math.floor(Math.random() * 4)],
    })),
  []);

  return (
    <div className="fixed inset-0 pointer-events-none" style={{ zIndex: 5 }}>
      {dots.map((d) => (
        <motion.div
          key={d.id}
          className="absolute rounded-full"
          style={{ left: d.left, top: d.top, width: d.size, height: d.size, background: d.color, boxShadow: `0 0 ${d.size * 3}px ${d.color}` }}
          animate={{ opacity: [0, 0.9, 0], scale: [0.5, 1.4, 0.5] }}
          transition={{ duration: d.dur, delay: d.del, repeat: Infinity, ease: 'easeInOut' }}
        />
      ))}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────

export default function Stage6Finale({
  onProposal,
}: {
  onProposal: () => void;
}) {
  const [phase, setPhase]               = useState(-1); // -1=black entry
  const [showFireworks, setShowFireworks] = useState(false);
  const [showHearts, setShowHearts]       = useState(false);

  useEffect(() => {
    const timers: ReturnType<typeof setTimeout>[] = [];

    PHASE_TIMES.forEach((ms, i) => {
      timers.push(setTimeout(() => {
        setPhase(i);
        if (i === 5) {
          setShowFireworks(true);
          setShowHearts(true);
        }
      }, ms));
    });

    return () => timers.forEach(clearTimeout);
  }, []);

  return (
    <>
      {/* Fireworks + effects layers (rendered outside the stacking container) */}
      <AnimatePresence>
        {showFireworks && (
          <motion.div key="fw" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1.5 }}>
            <Fireworks />
          </motion.div>
        )}
      </AnimatePresence>
      <AnimatePresence>
        {showHearts && (
          <motion.div key="fh" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 2 }}>
            <FloatingHearts />
          </motion.div>
        )}
      </AnimatePresence>
      <AnimatePresence>
        {showHearts && (
          <motion.div key="gp" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 2 }}>
            <GlowParticles />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main content */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 1.8 }}
        className="relative w-full h-full flex flex-col items-center justify-center px-6 text-center"
        style={{ zIndex: 10 }}
      >

        {/* ── PHASES 0–4: single scrolling messages ─────────────────────── */}
        <AnimatePresence mode="wait">
          {phase >= 0 && phase <= 4 && (
            <motion.div
              key={`msg-${phase}`}
              initial={{ opacity: 0, y: 30, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -24, scale: 0.96 }}
              transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
              className="max-w-sm"
            >
              <p
                className={`text-white drop-shadow-[0_2px_16px_rgba(0,0,0,0.9)] leading-relaxed font-serif ${MESSAGES[phase].italic ? 'italic' : ''} ${MESSAGES[phase].size === 'lg' ? 'text-2xl' : 'text-lg'}`}
              >
                {MESSAGES[phase].text}
              </p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ── PHASE 5+: "I Love You So Much ❤️" — stays + pulses ───────── */}
        <AnimatePresence>
          {phase >= 5 && (
            <motion.div
              key="love"
              initial={{ opacity: 0, scale: 0.7 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1] }}
              className="flex flex-col items-center gap-6 max-w-sm"
            >
              {/* Glowing love message */}
              <motion.p
                animate={{ scale: [1, 1.04, 1], textShadow: ['0 0 20px rgba(244,63,94,0.4)', '0 0 50px rgba(244,63,94,0.9)', '0 0 20px rgba(244,63,94,0.4)'] }}
                transition={{ duration: 2.2, repeat: Infinity, ease: 'easeInOut' }}
                className="text-3xl font-script text-white leading-tight drop-shadow-[0_2px_24px_rgba(244,63,94,0.8)]"
                style={{ fontFamily: "'Great Vibes', cursive" }}
              >
                {LOVE_MSG}
              </motion.p>

              {/* Phase 6: Happy Birthday */}
              <AnimatePresence>
                {phase >= 6 && (
                  <motion.p
                    key="bday"
                    initial={{ opacity: 0, y: 16 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 1.2, ease: 'easeOut' }}
                    className="text-xl font-serif text-white/95 drop-shadow-[0_2px_16px_rgba(0,0,0,0.8)]"
                  >
                    {BDAY_MSG}
                  </motion.p>
                )}
              </AnimatePresence>

              {/* Phase 7: Signature + replay */}
              <AnimatePresence>
                {phase >= 7 && (
                  <motion.div
                    key="sign"
                    initial={{ opacity: 0, y: 16 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 1.2, ease: 'easeOut' }}
                    className="flex flex-col items-center gap-5"
                  >
                    <p className="text-base font-serif italic text-white/80 leading-relaxed whitespace-pre-line drop-shadow-[0_2px_12px_rgba(0,0,0,0.8)]">
                      {SIGN_MSG}
                    </p>

                    <motion.button
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 2.2, duration: 0.8 }}
                      whileHover={{ scale: 1.04 }}
                      whileTap={{ scale: 0.96 }}
                      onClick={onProposal}
                      data-testid="button-continue-to-proposal"
                      className="flex items-center gap-2 px-6 py-2.5 rounded-full text-white/90 text-sm backdrop-blur-md border border-rose-300/30 bg-rose-500/15 hover:bg-rose-500/25 shadow-[0_0_22px_rgba(244,63,94,0.18)] transition-colors"
                    >
                      <Heart className="w-3.5 h-3.5 fill-rose-200/80 text-rose-200" />
                      <span className="tracking-wide">Continue to one more question</span>
                    </motion.button>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </>
  );
}
