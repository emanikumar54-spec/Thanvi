import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronRight } from 'lucide-react';

// CHANGE LETTER TEXT HERE
const LETTER_TEXT = `My Dear Egtttt ❤️,

Happy Birthday! 🎂

Thank you for coming into my life.
Every moment with you became a memory I'll always cherish.

Your smile is one of my favourite things in this world, and I hope it never fades.

On this special day, I just want to say...
Stay happy, stay healthy, and keep smiling.

Happy Birthday once again. ❤️

Forever Yours,
Bobby ❤️`;

export default function Stage4Letter({ onNext }: { onNext: () => void }) {
  const [displayedText, setDisplayedText] = useState('');
  const [isTypingComplete, setIsTypingComplete] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let currentIndex = 0;
    const intervalId = setInterval(() => {
      if (currentIndex <= LETTER_TEXT.length) {
        setDisplayedText(LETTER_TEXT.slice(0, currentIndex));
        currentIndex++;
        
        // Auto-scroll slightly to keep text in view
        if (scrollRef.current && currentIndex % 10 === 0) {
          scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
      } else {
        clearInterval(intervalId);
        setIsTypingComplete(true);
      }
    }, 45); // Typing speed

    return () => clearInterval(intervalId);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 1, ease: "easeOut" }}
      className="w-full h-full flex flex-col py-6 px-4 max-h-screen"
    >
      <div 
        ref={scrollRef}
        className="flex-1 glass-panel rounded-3xl p-6 md:p-10 overflow-y-auto custom-scrollbar flex flex-col relative"
      >
        <div className="absolute inset-0 pointer-events-none overflow-hidden rounded-3xl">
          {/* Subtle floating hearts in background */}
          {[...Array(6)].map((_, i) => (
            <motion.div
              key={i}
              initial={{ y: "100%", x: Math.random() * 100 - 50, opacity: 0 }}
              animate={{ 
                y: "-20%", 
                x: Math.random() * 100 - 50, 
                opacity: [0, 0.15, 0] 
              }}
              transition={{ 
                duration: 12 + Math.random() * 8, 
                repeat: Infinity,
                delay: Math.random() * 5,
                ease: "linear"
              }}
              className="absolute bottom-0 text-primary/30 text-2xl"
              style={{ left: `${10 + Math.random() * 80}%` }}
            >
              ❤
            </motion.div>
          ))}
        </div>

        <div className="relative z-10 whitespace-pre-wrap font-serif text-[1.1rem] leading-[1.8] text-white/90 tracking-wide">
          {displayedText}
          {!isTypingComplete && (
            <motion.span
              animate={{ opacity: [0, 1, 0] }}
              transition={{ repeat: Infinity, duration: 0.8 }}
              className="inline-block w-[2px] h-[1em] bg-primary/80 ml-1 translate-y-1 align-baseline"
            />
          )}
        </div>
      </div>

      <div className="h-20 flex items-center justify-center mt-4 shrink-0">
        <AnimatePresence>
          {isTypingComplete && (
            <motion.button
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.8 }}
              onClick={onNext}
              className="flex items-center gap-2 px-8 py-3 bg-white/10 hover:bg-white/20 text-white rounded-full transition-all border border-white/10 hover:border-white/30 backdrop-blur-md"
            >
              <span className="font-medium tracking-wide">Continue</span>
              <ChevronRight className="w-4 h-4" />
            </motion.button>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}