import React from 'react';
import { motion } from 'framer-motion';
import { Heart } from 'lucide-react';

export default function Stage1Welcome({ onNext }: { onNext: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20, scale: 0.95 }}
      transition={{ duration: 1, ease: "easeOut" }}
      className="flex flex-col items-center justify-center space-y-10 text-center px-6 h-full"
    >
      <motion.div
        animate={{ scale: [1, 1.05, 1], filter: ["drop-shadow(0 0 10px rgba(225,29,72,0.3))", "drop-shadow(0 0 20px rgba(225,29,72,0.6))", "drop-shadow(0 0 10px rgba(225,29,72,0.3))"] }}
        transition={{ repeat: Infinity, duration: 2.5, ease: "easeInOut" }}
      >
        <Heart className="w-20 h-20 text-primary fill-primary opacity-90" />
      </motion.div>
      
      <div className="space-y-4">
        <h1 className="text-4xl md:text-5xl font-serif text-white tracking-wide">
          A Special Surprise
        </h1>
        <p className="text-white/60 font-serif italic text-lg">
          Handcrafted with love, just for you.
        </p>
      </div>

      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={onNext}
        className="mt-8 px-8 py-4 bg-primary/20 hover:bg-primary/30 border border-primary/50 text-white rounded-full font-medium tracking-wide transition-all duration-300 backdrop-blur-md shadow-[0_0_20px_rgba(225,29,72,0.2)] flex items-center gap-2 group"
      >
        <span>Open My Surprise</span>
        <Heart className="w-4 h-4 fill-white text-white group-hover:scale-110 transition-transform" />
      </motion.button>
    </motion.div>
  );
}