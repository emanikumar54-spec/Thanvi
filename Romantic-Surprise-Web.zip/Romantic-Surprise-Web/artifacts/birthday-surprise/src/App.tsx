import React, { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import Stage1Welcome      from './components/Stage1Welcome';
import Stage2Password     from './components/Stage2Password';
import Stage3Intro        from './components/Stage3Intro';
import Stage4Letter       from './components/Stage4Letter';
import StageLoveCounter   from './components/StageLoveCounter';
import Stage5Album        from './components/Stage5Album';
import Stage6Finale       from './components/Stage6Finale';
import ProposalStage      from './components/ProposalStage';
import MusicPlayer        from './components/MusicPlayer';

// REPLACE BACKGROUND PHOTO URL HERE — swap the import below with your new image path
import bgPhoto from '@assets/IMG_20260722_121354_524_1784907421194.jpg';

const queryClient = new QueryClient();

//  Stage map
//  1 → Welcome
//  2 → Password
//  3 → Intro / cinematic transition
//  4 → Love letter
//  5 → Love story counter  ← NEW
//  6 → Photo album
//  7 → Cinematic finale
//  8 → Proposal heart + memory flashback

export default function App() {
  const [stage, setStage] = useState(1);

  const go = (n: number) => setStage(n);

  return (
    <QueryClientProvider client={queryClient}>
      {/*
        Fixed full-screen background — visible on ALL stages.
        position:fixed used instead of background-attachment:fixed
        for reliable behaviour on Android and iOS WebKit.
      */}
      <div
        style={{
          position: 'fixed', inset: 0, zIndex: 0,
          backgroundImage: `url(${bgPhoto})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat',
        }}
        aria-hidden="true"
      />

      {/* Overlay — light on normal stages, deep dark on finale */}
      <AnimatePresence>
        {stage < 7 ? (
          <motion.div
            key="overlay-normal"
            style={{ position: 'fixed', inset: 0, zIndex: 1 }}
            initial={{ background: 'rgba(0,0,0,0.25)' }}
            animate={{ background: 'rgba(0,0,0,0.25)' }}
            exit={{ background: 'rgba(0,0,0,0.80)' }}
            transition={{ duration: 1.8 }}
            aria-hidden="true"
          />
        ) : (
          <motion.div
            key="overlay-finale"
            style={{ position: 'fixed', inset: 0, zIndex: 1 }}
            initial={{ background: 'rgba(0,0,0,0.25)' }}
            animate={{ background: 'rgba(0,0,0,0.75)' }}
            transition={{ duration: 2 }}
            aria-hidden="true"
          />
        )}
      </AnimatePresence>

      {/* Floating music control */}
      <MusicPlayer />

      <div
        className="relative min-h-[100dvh] w-full text-foreground flex flex-col font-sans selection:bg-primary/30"
        style={{ zIndex: 2 }}
      >
        <div className="relative flex-1 flex flex-col items-center justify-center h-full w-full max-w-[500px] mx-auto overflow-hidden">
          <AnimatePresence mode="wait">
            {stage === 1 && <Stage1Welcome    key="s1" onNext={() => go(2)} />}
            {stage === 2 && <Stage2Password   key="s2" onNext={() => go(3)} />}
            {stage === 3 && <Stage3Intro      key="s3" onNext={() => go(4)} />}
            {stage === 4 && <Stage4Letter     key="s4" onNext={() => go(5)} />}
            {stage === 5 && <StageLoveCounter key="s5" onNext={() => go(6)} />}
            {stage === 6 && <Stage5Album      key="s6" onNext={() => go(7)} />}
            {stage === 7 && <Stage6Finale     key="s7" onProposal={() => go(8)} />}
            {stage === 8 && <ProposalStage key="s8" onReplay={() => go(1)} />}
          </AnimatePresence>
        </div>
      </div>
    </QueryClientProvider>
  );
}
